extends Camera2D

# Target limits that we will smoothly transition toward
var target_left: float = 0
var target_top: float = 0
var target_right: float = 1152
var target_bottom: float = 648

func _ready() -> void:
	# Make sure the camera anchor mode is correct
	anchor_mode = Camera2D.ANCHOR_MODE_DRAG_CENTER

func _process(delta: float) -> void:
	# Smoothly slide the actual camera limits toward our targets
	# Change '0.1' to adjust how fast or slow the room transition slides
	limit_left = lerp(float(limit_left), target_left, 0.1)
	limit_top = lerp(float(limit_top), target_top, 0.1)
	limit_right = lerp(float(limit_right), target_right, 0.1)
	limit_bottom = lerp(float(limit_bottom), target_bottom, 0.1)

func change_room_bounds(rect: Rect2) -> void:
	target_left = rect.position.x
	target_top = rect.position.y
	target_right = rect.end.x
	target_bottom = rect.end.y
