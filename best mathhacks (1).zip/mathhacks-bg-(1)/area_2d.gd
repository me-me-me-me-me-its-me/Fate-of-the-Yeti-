extends Area2D

@onready var collision_shape: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
	# Connect the signal when a body enters this room zone
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	# Make sure your player is in a group named "player" 
	# (or change this line to look for your player node name)
	if body.name == "player" or body.is_in_group("player"):
		# Get the pixel coordinates of our collision box
		var shape_rect: Rect2 = collision_shape.shape.get_rect()
		
		# Convert local rectangle to real world global coordinates
		var global_rect = Rect2(
			collision_shape.global_position + shape_rect.position,
			shape_rect.size
		)
		
		# Find the camera in your scene tree and update its bounds
		var camera = get_tree().current_scene.get_node("Camera2D")
		if camera:
			camera.change_room_bounds(global_rect)
