extends CharacterBody2D
var health = 3
@export var speed: float = 100
@onready var player: Node2D = get_tree().root.find_child("player", true, false)

func _physics_process(delta: float) -> void:
	if player:
		# Calculate direction and set speed
		var direction: Vector2 = global_position.direction_to(player.global_position)
		velocity = direction * speed
		
		# Look_at was removed here, so the sprite will not turn
		
		move_and_slide()
		
		
func _on_hitbox_area_entered(area: Area2D) -> void:
	if area is Bullet:
		health = health - 1
		area.queue_free()
		print("hit by bullet")
		print(health)
		if health <= 0:
			queue_free()
			area.queue_free()
