extends Node2D

const BULLET = preload("res://bullet.tscn")

func _process(delta: float) -> void:
	look_at(get_global_mouse_position())
	
	# Optional flip behavior if you want a sprite to turn upside down instead of spinning infinitely:
	# rotation_degrees = wrapf(rotation_degrees, 0, 360)
	# if rotation_degrees > 90 and rotation_degrees < 270:
	#     scale.y = -1
	# else:
	#     scale.y = 1

	if Input.is_action_just_pressed("shoot"):
		var bullet_instance = BULLET.instantiate()
		get_tree().root.add_child(bullet_instance)
		
		# Set global position and rotation AFTER adding to tree to avoid transform issues
		bullet_instance.global_position = global_position
		bullet_instance.rotation = rotation
