extends CharacterBody2D

var walk_speed = 175
var last_direction := Vector2(1,0)

@onready var bullet_scene = preload("res://scenes/bullet.tscn")



func shoot():
	var bullet = bullet_scene.instantiate()
	bullet.position = position
	
	bullet.bullet_direction = (get_global_mouse_position() - global_position).normalized()

	
	get_parent().add_child(bullet)

func _physics_process(delta):
	var direction = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if Input.is_action_pressed("sprint"):
		walk_speed = 300
		$AnimatedSprite2D.speed_scale = 1.7
	else:
		walk_speed = 175
		$AnimatedSprite2D.speed_scale = 1
	velocity = direction * walk_speed
	move_and_slide()
	
	if direction.length() > 0:
		last_direction = direction
		play_walk_animation(direction)
	else:
		play_idle_animation(last_direction)
		
	if Input.is_action_just_pressed("shoot"):
		shoot()
		

		
func play_walk_animation(direction):
	if direction.x > 0:
		$AnimatedSprite2D.flip_h = 0
		$AnimatedSprite2D.play("walk sideways")
	elif direction.x < 0:
		$AnimatedSprite2D.flip_h = 1
		$AnimatedSprite2D.play("walk sideways")
	elif direction.y > 0:
		$AnimatedSprite2D.play("walk down")
	elif direction.y < 0:
		$AnimatedSprite2D.play("walk up")
		
func play_idle_animation(direction):
	if direction.x > 0:
		$AnimatedSprite2D.flip_h = 0
		$AnimatedSprite2D.play("idle sideways")
	elif direction.x < 0:
		$AnimatedSprite2D.flip_h = 1
		$AnimatedSprite2D.play("idle sideways")
	elif direction.y > 0:
		$AnimatedSprite2D.play("idle down")
	elif direction.y < 0:
		$AnimatedSprite2D.play("idle up")


func _ready() -> void:
	var dashlength: float = 0.5
	var dir: int = 2
	pass

func _ticks(delta: float) -> void:
	var tick: float = 0
	tick = tick+0.01
	await get_tree().create_timer(0.01).timeout
	
	pass
