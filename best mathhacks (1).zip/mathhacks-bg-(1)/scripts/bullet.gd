extends Area2D
class_name Bullet

var speed = 700

var bullet_direction: Vector2 = Vector2.RIGHT 

func _process(delta: float) -> void:
 position += bullet_direction * speed * delta
pass
