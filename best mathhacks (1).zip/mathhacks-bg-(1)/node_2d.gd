extends Node2D

@onready var player = $player
@onready var camera = $Camera2D

# These match your standard window size so the camera aligns perfectly
const ROOM_WIDTH = 1152 
const ROOM_HEIGHT = 648

func _process(_delta: float) -> void:
	# 1. Calculate which room index the player is in based on their position
	var room_x = floor(player.global_position.x / ROOM_WIDTH)
	var room_y = floor(player.global_position.y / ROOM_HEIGHT)
	
	# 2. Find the exact center point of that room
	var target_camera_pos = Vector2(
		(room_x * ROOM_WIDTH) + (ROOM_WIDTH / 2),
		(room_y * ROOM_HEIGHT) + (ROOM_HEIGHT / 2)
	)
	
	# 3. Smoothly slide the camera to that room center
	camera.global_position = camera.global_position.lerp(target_camera_pos, 0.1)
